#!/bin/bash

# in these file we want to start the docker container
#--hostname=pdc --dns=<localhost>

#docker run --rm -t -i --hostname=pdc --dns=127.0.0.1 --dns-search=local.bolay.org --privileged -p 53:53 -p 53:53/udp -p 88:88 -p 88:88/udp -p 135:135 -p 137-138:137-138/udp -p 139:139 -p 389:389 -p 389:389/udp -p 445:445 -p 464:464 -p 464:464/udp -p 636:636 -p 1024-1044:1024-1044 -p 3268-3269:3268-3269 phusion/baseimage:latest /sbin/my_init -- bash -l
docker run -d  -p 53:53 -p 53:53/udp -p 88:88 -p 88:88/udp -p 135:135 -p 137-138:137-138/udp -p 139:139 -p 389:389 -p 389:389/udp -p 445:445 -p 464:464 -p 464:464/udp -p 636:636 -p 1024-1044:1024-1044 -p 3268-3269:3268-3269   --hostname=pdc --dns=127.0.0.1 jbolay/samba-ad-dc /sbin/my_init 
#docker run -P -it --hostname=pdc --dns=127.0.0.1 jbolay/samba-ad-dc /sbin/my_init -- bash -l
